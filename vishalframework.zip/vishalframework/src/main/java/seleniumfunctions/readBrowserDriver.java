package seleniumfunctions;

public class readBrowserDriver {
	public void readbrowser() {
		
	}

}
